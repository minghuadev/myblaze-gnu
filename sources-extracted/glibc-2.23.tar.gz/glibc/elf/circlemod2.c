extern void circlemod2_undefined (void);
extern int circlemod3 (void);

int
circlemod2 (void)
{
  circlemod2_undefined ();
  return circlemod3 ();
}
